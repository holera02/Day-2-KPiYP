﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Задание_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double x = Convert.ToDouble(textBox1.Text);
            double y = Convert.ToDouble(textBox2.Text);
            double z = Convert.ToDouble(textBox3.Text);
            double f = 1.2;
            double b = Math.Pow(y,Math.Pow(x,1/3)) + Math.Pow(Math.Cos(y),3) * (Math.Abs(x - y) * (1 + Math.Pow(Math.Sin(z),2) / Math.Sqrt(x + y)) / (Math.Pow(f,x - y) + x/2));
            textBox4.Text = b.ToString();
        }
    }
}
