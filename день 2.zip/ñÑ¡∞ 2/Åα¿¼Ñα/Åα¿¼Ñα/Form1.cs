﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace Пример
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            try
            {
                Test data = new Test(double.Parse(textBox1.Text),
               double.Parse(textBox2.Text), double.Parse(textBox3.Text));
                listBox1.Items.Add(data.ToString());
                listBox1.Items.Add(string.Format("Результат равен {0} ", data.Run()));
            }
            catch (Exception ex)
            {
                listBox1.Items.Add(ex.Message);
            }

        }
        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "Лабораторная работа №2";
        }
    }
    public class Test
    {
        private double x, y, z;

        public Test(double a, double b, double c)
        {

            x = a;
            y = b;
            z = c;
        }
        public double Run()
        {
            double result = Math.Pow(Math.Tan(x + y), 2) - Math.Exp(y - z) * Math.Sqrt(Math.Cos(x * x) + Math.Sin(z * z));
            return result;
        }
        public override string ToString()
        {
            return string.Format("для переменных x={0},y={1},z={2}", x, y, z);
        }
    }
}
