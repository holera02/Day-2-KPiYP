﻿using System;
using System.Windows.Forms;

namespace CosineSeries
{
    public partial class Form1 : Form
    {
        private object lblResult1;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            double x1 = Math.PI / 4; // значение x1
            double x2 = 1; // значение x2
            double x3 = Math.PI / 2; // значение x3
            double v = 0.001; // значение константы v
            double sum; // сумма ряда
            int n; // номер текущего члена ряда
            double prevSum; // предыдущее значение суммы ряда
            double currentTerm; // текущий член ряда
            double prevTerm; // предыдущий член ряда

            // рассчитываем значение ряда для x1
            sum = 0;
            prevSum = 0;
            n = 1;
            currentTerm = Math.Cos(x1);
            prevTerm = currentTerm;
            do
            {
                prevSum = sum;
                sum += currentTerm;
                prevTerm = currentTerm;
                currentTerm = (-1) * prevTerm * Math.Pow(x1, 2) / ((2 * n) * (2 * n - 1));
                n++;
            } while (Math.Abs(sum - prevSum) >= v);

            lblResult1.Text = $"F({x1}) = {sum:F5}";

            // рассчитываем значение ряда для x2
            sum = 0;
            prevSum = 0;
            n = 1;
            currentTerm = Math.Cos(x2);
            prevTerm = currentTerm;
            do
            {
                prevSum = sum;
                sum += currentTerm;
                prevTerm = currentTerm;
                currentTerm = (-1) * prevTerm * Math.Pow(x2, 2) / ((2 * n) * (2 * n - 1));
                n++;
            } while (Math.Abs(sum - prevSum) >= v);

            lblResult2.Text = $"F({x2}) = {sum:F5}";

            // рассчитываем значение ряда для x3
            sum = 0;
            prevSum = 0;
            n = 1;
            currentTerm = Math.Cos(x3);
            prevTerm = currentTerm;
            do
            {
                prevSum = sum;
                sum += currentTerm;
                prevTerm = currentTerm;
                currentTerm = (-1) * prevTerm * Math.Pow(x3, 2) / ((2 * n) * (2 * n - 1));
                n++;
            } while (Math.Abs(sum - prevSum) >= v);

            lblResult3.Text = $"F({x3}) = {sum:F5}";
        }
    }
}
