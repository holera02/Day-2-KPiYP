﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Задание_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double a = Convert.ToDouble(textBox1.Text);
            double b = Convert.ToDouble(textBox3.Text);
            double f = 1.2;
            double c = Math.Sqrt((Math.Pow(f, -(Math.Pow(a, 2) + f) / Math.Pow(a, 3) + b) * (1.7 * Math.Pow(a, 2) + Math.Pow(b, 3))) / (Math.Sin(b + Math.Pow(a, 2)) + Math.Cos(1.92 * (b / a))));
            textBox4.Text = c.ToString();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}


